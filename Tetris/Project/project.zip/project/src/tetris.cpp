/*
 * tetris.cpp
 *
 *  Created on: Nov 13, 2014
 *      Author: SRI
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <time.h>
#include <GL/glut.h>
#include "game.hpp"
using namespace std;

const int BLOCKSIZE = 30;
const int VPWIDTH = COLS * BLOCKSIZE; //windows size
const int VPHEIGHT = ROWS * BLOCKSIZE;

Game game = NULL; // THE game


void dropTimer(int id){
if(game.MoveY())
glutTimerFunc(10, dropTimer, 0);
glutPostRedisplay();
}

// timer - Callback for timers
void timer(int id)
{
if (game.killed) { // mode for when the user has been killed
exit(-1);
} else if (!game.paused) { // normal operation is when game
game.MoveY(); // is not paused
if (game.killed) {
glutTimerFunc(10, timer, 1);
} else {
glutPostRedisplay();
glutTimerFunc(game.timer, timer, 0);
}
}
}


void keyboard(unsigned char key, int x, int y)
{
if (key == 'p') {
game.paused = !game.paused;
if (!game.paused)
glutTimerFunc(game.timer, timer, 0);
glutPostRedisplay();
} else if (!game.paused && !game.killed && key == 's') { //down
game.score += ROWS - game.current.posY;
glutTimerFunc(10, dropTimer, 0);
}else if (!game.paused && !game.killed && key == 'a') { //right
game.MoveX(-1);
glutPostRedisplay();
}else if (!game.paused && !game.killed && key == 'd') { //left
game.MoveX(1);
glutPostRedisplay();
}else if (!game.paused && !game.killed && key == 'k') { //rotate
game.rotateShape(1);
glutPostRedisplay();
}
else if (game.killed && key == 'q')
exit(-1);
}

// display - Callback for displaying the grid and statistics.

void display(void)
{
glEnable(GL_BLEND);
glBlendFunc( GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA );
glClearColor(1.0f,1.0f,0.8f,0.5f);
glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

glViewport(0, 0, VPWIDTH, VPHEIGHT); //set window size

glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0, COLS, ROWS, 0);

//glBegin(GL_QUADS);
//glColor4f(1, 0, 0, 0.5);
//glVertex3d(0, 10, 0);
//glVertex3d(10, 10, 0);
//glVertex3d(10, 0, 0);
//glVertex3d(0, 0, 0);
//glEnd();

if(!game.paused)
for (int r=0; r<ROWS; r++) {
for (int c=0; c<COLS; c++) {
Tile &tile = game.grid[c][r];
if (tile.filled){
glColor4f(tile.red, tile.green, tile.blue, 0.5);
glRectf(c, r, c+1, r+1);

glLineWidth(2); //outline
glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
glVertex3f(c,r,0.5);
glVertex3f(c+1,r,0.5);
glVertex3f(c+1,r+1,0.5);
glVertex3f(c,r+1,0.5);
glEnd();
}
}
}

glutSwapBuffers();
}

void Sleep(unsigned int mseconds)
{
clock_t goal = mseconds + clock();
while (goal > clock());
}

void reDraw(){
display();
//Sleep(50000);
}

int main(int argc, char *argv[])
{
game = Game(reDraw);

srand((unsigned)time(0));
glutInit(&argc, argv);

glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

glutInitWindowPosition(100, 100);
glutInitWindowSize(VPWIDTH, VPHEIGHT);

glutCreateWindow("Tetris Game");
glutDisplayFunc(display);
glutKeyboardFunc(keyboard);
glutTimerFunc(game.timer, timer, 0);

glutMainLoop();

return 0;
}


